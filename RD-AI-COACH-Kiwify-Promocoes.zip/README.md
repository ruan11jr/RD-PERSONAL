# Welcome to your Lovable project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS
# RD AI Coach

## Assinaturas

O checkout é feito exclusivamente na Kiwify: `https://kiwify.app/49VOBX1`.

O profissional cria a conta no app e paga na Kiwify usando exatamente o mesmo e-mail. A liberação é automática: o webhook registra o pagamento e ativa a assinatura no Supabase assim que a Kiwify aprovar a venda.

## Configuração obrigatória

1. No ambiente de produção, crie os segredos `KIWIFY_WEBHOOK_SECRET` (uma senha longa e aleatória) e `KIWIFY_PRODUCT_ID` (o ID do produto na Kiwify).
2. Na Kiwify, vá em **Apps → Webhooks**, escolha o seu produto e o evento de compra aprovada. Use esta URL, substituindo os valores:
   `https://SEU-DOMINIO/api/public/mercadopago/webhook?token=SEU_KIWIFY_WEBHOOK_SECRET`
3. Use **Testar Webhook** na Kiwify. Crie uma conta de teste no app com o mesmo e-mail do evento e confirme que o painel muda para plano ativo.

O endpoint exige o segredo e só aceita eventos do produto configurado. Estornos, chargebacks e cancelamentos desativam a assinatura automaticamente.
