-- Kiwify recebe o pagamento. O app registra o pedido para ativação segura
-- após a confirmação da venda no painel da Kiwify.
CREATE TABLE public.subscription_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  purchase_email text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at timestamptz NOT NULL DEFAULT now(),
  reviewed_at timestamptz,
  reviewed_by uuid REFERENCES auth.users(id)
);

CREATE INDEX subscription_requests_user_id_idx ON public.subscription_requests(user_id);
CREATE UNIQUE INDEX subscription_requests_one_pending_per_user_idx
  ON public.subscription_requests(user_id) WHERE status = 'pending';

GRANT SELECT, INSERT ON public.subscription_requests TO authenticated;
GRANT ALL ON public.subscription_requests TO service_role;
ALTER TABLE public.subscription_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own subscription requests select" ON public.subscription_requests
  FOR SELECT TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "own subscription requests insert" ON public.subscription_requests
  FOR INSERT TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);
