import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Sparkles, Users, Dumbbell, Trophy, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PLANS, formatBRL, monthlyEquivalent } from "@/lib/plans";
import { getKiwifyCheckoutUrl } from "@/lib/kiwify";

const title = "RD AI Coach — App de treinos com IA para Personal Trainer";
const description =
  "Gerencie alunos, monte treinos e use IA no seu atendimento. Grátis até 2 alunos, R$ 49,90/mês para alunos ilimitados.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { name: "theme-color", content: "#053b3d" },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/rd-ai-icon.svg" },
    ],
  }),
  component: Home,
});

const features = [
  { icon: Users, title: "Seus alunos organizados", text: "Cadastro, objetivos e histórico em um só lugar." },
  { icon: Dumbbell, title: "Treinos por dia", text: "Monte a semana e acompanhe a execução série a série." },
  { icon: Sparkles, title: "Assistente com IA", text: "Sugestões de ajuste de carga, volume e progressão." },
  { icon: Trophy, title: "Gamificação", text: "Pontos, níveis e ranking para engajar quem treina." },
];

function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-30 border-b border-border/60 bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-3">
          <span className="flex items-center gap-2 font-semibold">
            <img src="/rd-ai-icon.svg" alt="" className="h-7 w-7" aria-hidden />
            RD AI Coach
          </span>
          <nav className="flex items-center gap-2">
            <Button asChild variant="ghost" size="sm">
              <Link to="/demo">Ver demo</Link>
            </Button>
            <Button asChild size="sm" className="bg-brand text-primary-foreground">
              <Link to="/auth">Entrar</Link>
            </Button>
          </nav>
        </div>
      </header>

      <main>
        <section className="mx-auto max-w-5xl px-5 pb-14 pt-16 text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
            <Sparkles className="h-3.5 w-3.5" /> Feito para personal trainers
          </span>
          <h1 className="mt-5 text-4xl font-extrabold sm:text-5xl">
            O app do seu <span className="text-brand">personal</span>, com IA de verdade
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-base text-muted-foreground">{description}</p>
          <div className="mt-7 flex flex-wrap justify-center gap-3">
            <Button asChild size="lg" className="bg-brand text-primary-foreground shadow-soft">
              <Link to="/auth">
                Começar grátis <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/demo">Explorar o app</Link>
            </Button>
          </div>
        </section>

        <section className="mx-auto grid max-w-5xl gap-4 px-5 pb-16 sm:grid-cols-2">
          {features.map((f) => (
            <div key={f.title} className="rounded-2xl border border-border bg-card p-5 shadow-soft">
              <f.icon className="h-5 w-5 text-primary" />
              <h3 className="mt-3 text-base font-bold">{f.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.text}</p>
            </div>
          ))}
        </section>

        <section id="planos" className="mx-auto max-w-5xl px-5 pb-20">
          <h2 className="text-center text-2xl font-extrabold">Planos</h2>
          <p className="mt-2 text-center text-sm text-muted-foreground">
            Use grátis com até 2 alunos. Assine para liberar alunos ilimitados e a IA.
          </p>

          <div className="mt-8 grid gap-4 md:grid-cols-2">
            <div className="rounded-3xl border border-border bg-card p-6 shadow-soft">
              <h3 className="text-lg font-bold">Grátis</h3>
              <p className="mt-1 text-3xl font-extrabold">R$ 0</p>
              <ul className="mt-4 space-y-2 text-sm">
                {["Até 2 alunos", "Treinos e acompanhamento", "Design completo do app"].map((i) => (
                  <li key={i} className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-primary" /> {i}
                  </li>
                ))}
              </ul>
              <Button asChild variant="outline" className="mt-6 w-full">
                <Link to="/auth">Criar conta</Link>
              </Button>
            </div>

            <div className="rounded-3xl bg-deep-gradient p-6 text-deep-foreground shadow-strong">
              <h3 className="text-lg font-bold">Ilimitado + IA</h3>
              <p className="mt-1 text-3xl font-extrabold">R$ 39,90<span className="text-base font-medium">/mês</span></p>
              <ul className="mt-4 space-y-2 text-sm">
                {["Alunos ilimitados", "Assistente de IA liberado", "Pagamento seguro via Kiwify"].map((i) => (
                  <li key={i} className="flex items-center gap-2">
                    <Check className="h-4 w-4" /> {i}
                  </li>
                ))}
              </ul>
              <div className="mt-5 grid grid-cols-2 gap-2 text-xs">
                {PLANS.map((p) => (
                  <a key={p.id} href={getKiwifyCheckoutUrl(p.id)} target="_blank" rel="noreferrer" className="rounded-xl bg-white/10 p-3 transition hover:bg-white/20">
                    <p className="font-semibold">{p.label}</p>
                    <p className="mt-1 text-sm font-bold">{formatBRL(p.totalCents)}</p>
                    <p className="opacity-80">
                      {monthlyEquivalent(p.totalCents, p.months)}/mês
                      {p.discount > 0 ? ` · ${Math.round(p.discount * 100)}% off` : ""}
                    </p>
                  </a>
                ))}
              </div>
              <Button asChild className="mt-6 w-full bg-brand text-primary-foreground">
                <a href={getKiwifyCheckoutUrl("m12")} target="_blank" rel="noreferrer">Assinar plano anual</a>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-border py-8 text-center text-xs text-muted-foreground">
        RD AI Coach · Treino inteligente para personal trainers
      </footer>
    </div>
  );
}
