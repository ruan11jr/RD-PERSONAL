import { createFileRoute, Link, useSearch } from "@tanstack/react-router";
import { CheckCircle2, Clock, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/pagamento")({
  validateSearch: (search: Record<string, unknown>) => ({
    status: typeof search["status"] === "string" ? (search["status"] as string) : "pendente",
  }),
  head: () => ({
    meta: [
      { title: "Status do pagamento — RD AI Coach" },
      { name: "description", content: "Confirmação do pagamento da assinatura RD AI Coach." },
      { property: "og:title", content: "Status do pagamento — RD AI Coach" },
      { property: "og:description", content: "Confirmação do pagamento da assinatura." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Pagamento,
});

function Pagamento() {
  const { status } = useSearch({ from: "/pagamento" });

  const map = {
    sucesso: {
      icon: CheckCircle2,
      title: "Pagamento aprovado!",
      text: "Sua assinatura será liberada em instantes. Volte ao painel.",
    },
    pendente: {
      icon: Clock,
      title: "Pagamento pendente",
      text: "Após a confirmação da compra na Kiwify, seu plano será liberado automaticamente no painel.",
    },
    falha: {
      icon: XCircle,
      title: "Pagamento não concluído",
      text: "Nenhuma cobrança foi feita. Você pode tentar novamente pelo painel.",
    },
  } as const;

  const view = map[(status as keyof typeof map) in map ? (status as keyof typeof map) : "pendente"];

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-5">
      <div className="max-w-sm rounded-3xl border border-border bg-card p-7 text-center shadow-soft">
        <view.icon className="mx-auto h-10 w-10 text-primary" />
        <h1 className="mt-4 text-xl font-extrabold">{view.title}</h1>
        <p className="mt-2 text-sm text-muted-foreground">{view.text}</p>
        <Button asChild className="mt-6 w-full bg-brand text-primary-foreground">
          <Link to="/painel">Ir para o painel</Link>
        </Button>
      </div>
    </div>
  );
}
