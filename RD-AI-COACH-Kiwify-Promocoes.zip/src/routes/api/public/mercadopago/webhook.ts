import { createFileRoute } from "@tanstack/react-router";
import { MONTHLY_CENTS } from "@/lib/plans";

type KiwifyPayload = Record<string, unknown>;

function text(payload: KiwifyPayload, paths: string[][]) {
  for (const path of paths) {
    let value: unknown = payload;
    for (const key of path) value = value && typeof value === "object" ? (value as Record<string, unknown>)[key] : undefined;
    if (typeof value === "string" && value.trim()) return value.trim();
    if (typeof value === "number") return String(value);
  }
  return null;
}

async function handleKiwifyNotification(payload: KiwifyPayload) {
  const email = text(payload, [["Customer", "email"], ["customer", "email"], ["email"]])?.toLowerCase();
  const orderId = text(payload, [["order_id"], ["orderId"], ["id"], ["order", "id"], ["transaction_id"]]);
  const status = text(payload, [["order_status"], ["status"], ["order", "status"]])?.toLowerCase();
  const productId = text(payload, [["Product", "product_id"], ["product_id"], ["product", "id"]]);

  if (!email || !orderId || !status) throw new Error("Evento Kiwify sem comprador, pedido ou status");
  if (process.env["KIWIFY_PRODUCT_ID"] && productId !== process.env["KIWIFY_PRODUCT_ID"]) {
    throw new Error("Produto Kiwify não autorizado");
  }

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: profile } = await supabaseAdmin.from("profiles").select("id").eq("email", email).maybeSingle();
  if (!profile) throw new Error("Não existe conta RD AI Coach com o e-mail da compra");

  const paid = ["paid", "approved", "completed", "complete"].includes(status);
  const cancelled = ["refunded", "chargeback", "cancelled", "canceled"].includes(status);
  const reference = `kiwify:${orderId}`;

  const { error: paymentError } = await supabaseAdmin.from("payments").upsert(
    {
      user_id: profile.id,
      provider: "kiwify",
      external_reference: reference,
      payment_id: orderId,
      months: 1,
      amount_cents: MONTHLY_CENTS,
      status,
    },
    { onConflict: "external_reference" },
  );
  if (paymentError) throw new Error(paymentError.message);
  if (!paid && !cancelled) return;

  if (cancelled) {
    await supabaseAdmin.from("subscriptions").update({ status: "inactive", updated_at: new Date().toISOString() }).eq("user_id", profile.id);
    return;
  }

  const { data: current } = await supabaseAdmin.from("subscriptions").select("current_period_end").eq("user_id", profile.id).maybeSingle();
  const now = new Date();
  const base = current?.current_period_end && new Date(current.current_period_end) > now ? new Date(current.current_period_end) : now;
  const end = new Date(base);
  end.setMonth(end.getMonth() + 1);

  const { error: subscriptionError } = await supabaseAdmin.from("subscriptions").upsert(
    { user_id: profile.id, plan: "pro", months: 1, status: "active", current_period_end: end.toISOString(), updated_at: now.toISOString() },
    { onConflict: "user_id" },
  );
  if (subscriptionError) throw new Error(subscriptionError.message);
}

export const Route = createFileRoute("/api/public/mercadopago/webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const url = new URL(request.url);
          const secret = process.env["KIWIFY_WEBHOOK_SECRET"];
          if (!secret || url.searchParams.get("token") !== secret) return new Response("unauthorized", { status: 401 });
          const body = (await request.json()) as KiwifyPayload;
          await handleKiwifyNotification(body);
          return new Response("ok");
        } catch (error) {
          console.error("Kiwify webhook error", error);
          return new Response("invalid webhook", { status: 400 });
        }
      },
      GET: async () => new Response("ok"),
    },
  },
});
