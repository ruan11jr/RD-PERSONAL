import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { Crown, ExternalLink, FilePenLine, LogOut, Plus, Trash2, Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FREE_STUDENT_LIMIT, formatBRL, PLANS } from "@/lib/plans";
import { getMyBilling } from "@/lib/billing.functions";
import { getKiwifyCheckoutUrl } from "@/lib/kiwify";
import { listStudents, createStudent, deleteStudent, updateStudent } from "@/lib/students.functions";

export const Route = createFileRoute("/_authenticated/painel")({
  head: () => ({
    meta: [
      { title: "Painel do personal — RD AI Coach" },
      { name: "description", content: "Gerencie seus alunos e sua assinatura no RD AI Coach." },
      { property: "og:title", content: "Painel do personal — RD AI Coach" },
      { property: "og:description", content: "Gerencie seus alunos e sua assinatura." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Painel,
});

function Painel() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const fetchBilling = useServerFn(getMyBilling);
  const fetchStudents = useServerFn(listStudents);
  const addStudent = useServerFn(createStudent);
  const removeStudent = useServerFn(deleteStudent);
  const saveStudent = useServerFn(updateStudent);

  const [name, setName] = useState("");
  const [goal, setGoal] = useState("");
  const [phone, setPhone] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [notes, setNotes] = useState("");

  const billing = useQuery({ queryKey: ["billing"], queryFn: () => fetchBilling() });
  const students = useQuery({ queryKey: ["students"], queryFn: () => fetchStudents() });

  const createMutation = useMutation({
    mutationFn: () => addStudent({ data: { name, goal, phone } }),
    onSuccess: (result) => {
      if (result.limitReached) {
        toast.error("Limite do plano grátis atingido (2 alunos). Assine para liberar ilimitado.");
        return;
      }
      setName("");
      setGoal("");
      setPhone("");
      toast.success("Aluno cadastrado");
      queryClient.invalidateQueries({ queryKey: ["students"] });
      queryClient.invalidateQueries({ queryKey: ["billing"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => removeStudent({ data: { id } }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["students"] });
      queryClient.invalidateQueries({ queryKey: ["billing"] });
    },
  });

  const updateMutation = useMutation({
    mutationFn: (student: { id: string; name: string; goal: string | null; phone: string | null }) =>
      saveStudent({ data: { ...student, notes } }),
    onSuccess: () => {
      setEditingId(null);
      setNotes("");
      toast.success("Ficha do aluno atualizada");
      queryClient.invalidateQueries({ queryKey: ["students"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const active = billing.data?.active ?? false;
  const count = students.data?.length ?? 0;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-5 py-3">
          <span className="flex items-center gap-2 font-semibold">
            <img src="/rd-ai-icon.svg" alt="" className="h-7 w-7" aria-hidden />
            Painel
          </span>
          <Button
            variant="ghost"
            size="sm"
            onClick={async () => {
              await supabase.auth.signOut();
              queryClient.clear();
              navigate({ to: "/auth" });
            }}
          >
            <LogOut className="mr-1 h-4 w-4" /> Sair
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-3xl space-y-5 px-5 py-6">
        <section
          className={
            active
              ? "rounded-3xl bg-deep-gradient p-5 text-deep-foreground shadow-strong"
              : "rounded-3xl border border-border bg-card p-5 shadow-soft"
          }
        >
          <div className="flex items-center gap-2">
            <Crown className="h-5 w-5" />
            <h2 className="text-base font-bold">
              {active ? "Plano ilimitado ativo" : "Plano grátis"}
            </h2>
          </div>
          <p className={active ? "mt-1 text-sm opacity-90" : "mt-1 text-sm text-muted-foreground"}>
            {active
              ? `Válido até ${billing.data?.currentPeriodEnd ? new Date(billing.data.currentPeriodEnd).toLocaleDateString("pt-BR") : "-"}`
              : `${count} de ${FREE_STUDENT_LIMIT} alunos usados. Assine para liberar alunos ilimitados e a IA.`}
          </p>

          {!active && (
            <div className="mt-4 grid gap-3">
              <div>
                <p className="text-sm font-semibold">Plano Profissional — R$ 39,90/mês</p>
                <p className="mt-1 text-xs text-muted-foreground">Pagamento seguro pela Kiwify. Use o mesmo e-mail da sua conta RD AI Coach: a liberação é automática após a aprovação.</p>
              </div>
              <div className="grid gap-2 sm:grid-cols-4">
                {PLANS.map((plan) => (
                  <Button key={plan.id} asChild variant={plan.id === "m12" ? "default" : "outline"} className={plan.id === "m12" ? "bg-brand text-primary-foreground" : ""}>
                    <a href={getKiwifyCheckoutUrl(plan.id)} target="_blank" rel="noreferrer">
                      {plan.label} · {formatBRL(plan.totalCents)} <ExternalLink className="ml-1 h-3 w-3" />
                    </a>
                  </Button>
                ))}
              </div>
            </div>
          )}
          <p className={active ? "mt-3 text-[11px] opacity-75" : "mt-3 text-[11px] text-muted-foreground"}>
            {active ? "Sua assinatura está ativa." : "A ativação acontece automaticamente após a aprovação da compra na Kiwify."}
          </p>
        </section>

        <section className="rounded-3xl border border-border bg-card p-5 shadow-soft">
          <h2 className="flex items-center gap-2 text-base font-bold">
            <Plus className="h-4 w-4" /> Novo aluno
          </h2>
          <form
            className="mt-4 grid gap-3 sm:grid-cols-3"
            onSubmit={(e) => {
              e.preventDefault();
              createMutation.mutate();
            }}
          >
            <div className="space-y-1.5">
              <Label htmlFor="sname">Nome</Label>
              <Input id="sname" value={name} onChange={(e) => setName(e.target.value)} required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="sgoal">Objetivo</Label>
              <Input id="sgoal" value={goal} onChange={(e) => setGoal(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="sphone">WhatsApp</Label>
              <Input id="sphone" value={phone} onChange={(e) => setPhone(e.target.value)} />
            </div>
            <Button
              type="submit"
              disabled={createMutation.isPending}
              className="bg-brand text-primary-foreground sm:col-span-3"
            >
              Cadastrar aluno
            </Button>
          </form>
        </section>

        <section className="rounded-3xl border border-border bg-card p-5 shadow-soft">
          <h2 className="flex items-center gap-2 text-base font-bold">
            <Users className="h-4 w-4" /> Meus alunos ({count})
          </h2>
          <ul className="mt-3 divide-y divide-border">
            {students.isLoading && <li className="py-3 text-sm text-muted-foreground">Carregando...</li>}
            {!students.isLoading && count === 0 && (
              <li className="py-3 text-sm text-muted-foreground">Nenhum aluno cadastrado ainda.</li>
            )}
            {students.data?.map((s) => (
              <li key={s.id} className="py-3">
                <div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-semibold">{s.name}</p>
                      <p className="text-xs text-muted-foreground">{s.goal ?? "Sem objetivo definido"}{s.phone ? ` · ${s.phone}` : ""}</p>
                    </div>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="sm" onClick={() => { setEditingId(editingId === s.id ? null : s.id); setNotes(s.notes ?? ""); }}><FilePenLine className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="sm" onClick={() => deleteMutation.mutate(s.id)}><Trash2 className="h-4 w-4" /></Button>
                    </div>
                  </div>
                  {editingId === s.id && (
                    <div className="mt-3 space-y-2 rounded-xl bg-muted/50 p-3">
                      <Label htmlFor={`notes-${s.id}`}>Ficha / observações</Label>
                      <textarea id={`notes-${s.id}`} className="min-h-24 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Restrições, histórico, medidas, treino atual e observações..." />
                      <Button size="sm" disabled={updateMutation.isPending} onClick={() => updateMutation.mutate({ id: s.id, name: s.name, goal: s.goal, phone: s.phone })}>Salvar ficha</Button>
                    </div>
                  )}
                </div>
              </li>
            ))}
          </ul>
        </section>
      </main>
    </div>
  );
}
