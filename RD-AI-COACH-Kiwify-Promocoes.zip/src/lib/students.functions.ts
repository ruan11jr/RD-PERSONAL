import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const listStudents = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("students")
      .select("id, name, goal, phone, notes, created_at")
      .eq("coach_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const createStudent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { name: string; goal?: string; phone?: string }) => {
    const name = input.name?.trim();
    if (!name) throw new Error("Informe o nome do aluno");
    return { name, goal: input.goal?.trim() || null, phone: input.phone?.trim() || null };
  })
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("students")
      .insert({ ...data, coach_id: context.userId });
    if (error) {
      if (error.message.includes("LIMITE_PLANO_GRATIS")) {
        return { ok: false, limitReached: true };
      }
      throw new Error(error.message);
    }
    return { ok: true, limitReached: false };
  });

export const updateStudent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string; name: string; goal?: string; phone?: string; notes?: string }) => {
    const name = input.name?.trim();
    if (!input.id || !name) throw new Error("Nome do aluno é obrigatório");
    return {
      id: input.id,
      name,
      goal: input.goal?.trim() || null,
      phone: input.phone?.trim() || null,
      notes: input.notes?.trim() || null,
    };
  })
  .handler(async ({ data, context }) => {
    const { id, ...student } = data;
    const { error } = await context.supabase
      .from("students")
      .update(student)
      .eq("id", id)
      .eq("coach_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteStudent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => input)
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("students")
      .delete()
      .eq("id", data.id)
      .eq("coach_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
