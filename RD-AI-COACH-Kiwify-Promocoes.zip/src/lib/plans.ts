export type PlanId = "m1" | "m3" | "m6" | "m12";

export const MONTHLY_CENTS = 3990;

export const PLANS: {
  id: PlanId;
  months: number;
  label: string;
  discount: number;
  totalCents: number;
}[] = [
  { id: "m1", months: 1, label: "Mensal", discount: 0, totalCents: 3990 },
  { id: "m3", months: 3, label: "3 meses", discount: 0.05, totalCents: 11372 },
  { id: "m6", months: 6, label: "6 meses", discount: 0.05, totalCents: 22743 },
  { id: "m12", months: 12, label: "12 meses", discount: 0.15, totalCents: 40698 },
];

export function getPlan(id: string) {
  return PLANS.find((p) => p.id === id);
}

export function formatBRL(cents: number) {
  return (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export function monthlyEquivalent(cents: number, months: number) {
  return formatBRL(Math.round(cents / months));
}

export const FREE_STUDENT_LIMIT = 2;
