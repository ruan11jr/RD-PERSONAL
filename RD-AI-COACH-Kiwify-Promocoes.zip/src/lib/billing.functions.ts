import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const getMyBilling = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const [{ data: sub }, { count }] = await Promise.all([
      supabase
        .from("subscriptions")
        .select("plan, months, status, current_period_end")
        .eq("user_id", userId)
        .maybeSingle(),
      supabase.from("students").select("id", { count: "exact", head: true }).eq("coach_id", userId),
    ]);

    const active =
      !!sub &&
      sub.status === "active" &&
      (!sub.current_period_end || new Date(sub.current_period_end) > new Date());

    return {
      active,
      plan: sub?.plan ?? "free",
      months: sub?.months ?? 0,
      currentPeriodEnd: sub?.current_period_end ?? null,
      studentCount: count ?? 0,
    };
  });

export const requestKiwifyActivation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { purchaseEmail: string }) => {
    const purchaseEmail = input.purchaseEmail?.trim().toLowerCase();
    if (!purchaseEmail || !/^\S+@\S+\.\S+$/.test(purchaseEmail)) {
      throw new Error("Informe o e-mail usado na compra da Kiwify");
    }
    return { purchaseEmail };
  })
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("subscription_requests").insert({
      user_id: context.userId,
      purchase_email: data.purchaseEmail,
    });
    if (error?.code === "23505") return { alreadyRequested: true };
    if (error) throw new Error(error.message);
    return { alreadyRequested: false };
  });
