import type { PlanId } from "@/lib/plans";

export const KIWIFY_CHECKOUT_URLS: Record<PlanId, string> = {
  m1: "https://pay.kiwify.com.br/y5q1Y6Z",
  m3: "https://pay.kiwify.com.br/2NPFDKb",
  m6: "https://pay.kiwify.com.br/2PhxkMs",
  m12: "https://pay.kiwify.com.br/GQRtRzR",
};

export function getKiwifyCheckoutUrl(planId: PlanId) {
  return KIWIFY_CHECKOUT_URLS[planId];
}
